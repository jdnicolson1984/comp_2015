//JAMES NICOLSON
document.getElementById('bird').style.width = document.getElementById('cat').style.width;